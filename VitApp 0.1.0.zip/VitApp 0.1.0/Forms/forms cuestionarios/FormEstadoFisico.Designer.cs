﻿namespace VitApp_0._1._0.Otros_forms.forms_cuestionarios
{
    partial class FormEstadoFisico
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
            this.guna2ControlBox1 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.guna2ControlBox2 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.guna2ControlBox3 = new Guna.UI2.WinForms.Guna2ControlBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.GbxQ1 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.lbl1Q3 = new System.Windows.Forms.Label();
            this.lbl1Q2 = new System.Windows.Forms.Label();
            this.lbl1Q4 = new System.Windows.Forms.Label();
            this.lbl1Q1 = new System.Windows.Forms.Label();
            this.Rbtn1Q4 = new Guna.UI2.WinForms.Guna2CustomRadioButton();
            this.Rbtn1Q3 = new Guna.UI2.WinForms.Guna2CustomRadioButton();
            this.Rbtn1Q2 = new Guna.UI2.WinForms.Guna2CustomRadioButton();
            this.Rbtn1Q1 = new Guna.UI2.WinForms.Guna2CustomRadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.GbxQ2 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.lbl2Q3 = new System.Windows.Forms.Label();
            this.lbl2Q2 = new System.Windows.Forms.Label();
            this.Rbtn2Q3 = new Guna.UI2.WinForms.Guna2CustomRadioButton();
            this.lbl2Q1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Rbtn2Q2 = new Guna.UI2.WinForms.Guna2CustomRadioButton();
            this.Rbtn2Q1 = new Guna.UI2.WinForms.Guna2CustomRadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.GbxQ3 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.lbl3Q3 = new System.Windows.Forms.Label();
            this.lbl3Q2 = new System.Windows.Forms.Label();
            this.lbl3Q1 = new System.Windows.Forms.Label();
            this.Rbtn3Q3 = new Guna.UI2.WinForms.Guna2CustomRadioButton();
            this.Rbtn3Q2 = new Guna.UI2.WinForms.Guna2CustomRadioButton();
            this.Rbtn3Q1 = new Guna.UI2.WinForms.Guna2CustomRadioButton();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.GbxQ4 = new Guna.UI2.WinForms.Guna2GroupBox();
            this.lbl4Q3 = new System.Windows.Forms.Label();
            this.lbl4Q2 = new System.Windows.Forms.Label();
            this.lbl4Q1 = new System.Windows.Forms.Label();
            this.Rbtn4Q3 = new Guna.UI2.WinForms.Guna2CustomRadioButton();
            this.label9 = new System.Windows.Forms.Label();
            this.Rbtn4Q2 = new Guna.UI2.WinForms.Guna2CustomRadioButton();
            this.Rbtn4Q1 = new Guna.UI2.WinForms.Guna2CustomRadioButton();
            this.label10 = new System.Windows.Forms.Label();
            this.guna2TileButton2 = new Guna.UI2.WinForms.Guna2TileButton();
            this.BtnAtrás = new Guna.UI2.WinForms.Guna2TileButton();
            this.GbxQ1.SuspendLayout();
            this.GbxQ2.SuspendLayout();
            this.GbxQ3.SuspendLayout();
            this.GbxQ4.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2BorderlessForm1
            // 
            this.guna2BorderlessForm1.ContainerControl = this;
            this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            this.guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // guna2ControlBox1
            // 
            this.guna2ControlBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(87)))), ((int)(((byte)(82)))));
            this.guna2ControlBox1.IconColor = System.Drawing.Color.White;
            this.guna2ControlBox1.Location = new System.Drawing.Point(1095, 12);
            this.guna2ControlBox1.Name = "guna2ControlBox1";
            this.guna2ControlBox1.Size = new System.Drawing.Size(45, 29);
            this.guna2ControlBox1.TabIndex = 1;
            // 
            // guna2ControlBox2
            // 
            this.guna2ControlBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox2.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MaximizeBox;
            this.guna2ControlBox2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(87)))), ((int)(((byte)(82)))));
            this.guna2ControlBox2.IconColor = System.Drawing.Color.White;
            this.guna2ControlBox2.Location = new System.Drawing.Point(1035, 12);
            this.guna2ControlBox2.Name = "guna2ControlBox2";
            this.guna2ControlBox2.Size = new System.Drawing.Size(45, 29);
            this.guna2ControlBox2.TabIndex = 2;
            // 
            // guna2ControlBox3
            // 
            this.guna2ControlBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.guna2ControlBox3.ControlBoxType = Guna.UI2.WinForms.Enums.ControlBoxType.MinimizeBox;
            this.guna2ControlBox3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(58)))), ((int)(((byte)(87)))), ((int)(((byte)(82)))));
            this.guna2ControlBox3.IconColor = System.Drawing.Color.White;
            this.guna2ControlBox3.Location = new System.Drawing.Point(973, 12);
            this.guna2ControlBox3.Name = "guna2ControlBox3";
            this.guna2ControlBox3.Size = new System.Drawing.Size(45, 29);
            this.guna2ControlBox3.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(481, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(163, 29);
            this.label1.TabIndex = 4;
            this.label1.Text = "Estado físico";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(149)))), ((int)(((byte)(127)))));
            this.label2.Location = new System.Drawing.Point(217, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(588, 21);
            this.label2.TabIndex = 33;
            this.label2.Text = "¿Con qué frecuencia realiza actividad física en una semana típica?";
            // 
            // GbxQ1
            // 
            this.GbxQ1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(41)))), ((int)(((byte)(42)))));
            this.GbxQ1.Controls.Add(this.lbl1Q3);
            this.GbxQ1.Controls.Add(this.lbl1Q2);
            this.GbxQ1.Controls.Add(this.lbl1Q4);
            this.GbxQ1.Controls.Add(this.lbl1Q1);
            this.GbxQ1.Controls.Add(this.Rbtn1Q4);
            this.GbxQ1.Controls.Add(this.Rbtn1Q3);
            this.GbxQ1.Controls.Add(this.label2);
            this.GbxQ1.Controls.Add(this.Rbtn1Q2);
            this.GbxQ1.Controls.Add(this.Rbtn1Q1);
            this.GbxQ1.Controls.Add(this.label5);
            this.GbxQ1.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(41)))), ((int)(((byte)(42)))));
            this.GbxQ1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(41)))), ((int)(((byte)(42)))));
            this.GbxQ1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GbxQ1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.GbxQ1.Location = new System.Drawing.Point(36, 68);
            this.GbxQ1.Name = "GbxQ1";
            this.GbxQ1.Size = new System.Drawing.Size(1073, 125);
            this.GbxQ1.TabIndex = 6;
            this.GbxQ1.Text = "1.";
            // 
            // lbl1Q3
            // 
            this.lbl1Q3.AutoSize = true;
            this.lbl1Q3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1Q3.ForeColor = System.Drawing.Color.White;
            this.lbl1Q3.Location = new System.Drawing.Point(537, 69);
            this.lbl1Q3.Name = "lbl1Q3";
            this.lbl1Q3.Size = new System.Drawing.Size(202, 21);
            this.lbl1Q3.TabIndex = 43;
            this.lbl1Q3.Text = "3-4 veces por semana";
            // 
            // lbl1Q2
            // 
            this.lbl1Q2.AutoSize = true;
            this.lbl1Q2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1Q2.ForeColor = System.Drawing.Color.White;
            this.lbl1Q2.Location = new System.Drawing.Point(297, 69);
            this.lbl1Q2.Name = "lbl1Q2";
            this.lbl1Q2.Size = new System.Drawing.Size(202, 21);
            this.lbl1Q2.TabIndex = 42;
            this.lbl1Q2.Text = "1-2 veces por semana";
            // 
            // lbl1Q4
            // 
            this.lbl1Q4.AutoSize = true;
            this.lbl1Q4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1Q4.ForeColor = System.Drawing.Color.White;
            this.lbl1Q4.Location = new System.Drawing.Point(778, 67);
            this.lbl1Q4.Name = "lbl1Q4";
            this.lbl1Q4.Size = new System.Drawing.Size(244, 21);
            this.lbl1Q4.TabIndex = 42;
            this.lbl1Q4.Text = "5 o más veces por semana";
            // 
            // lbl1Q1
            // 
            this.lbl1Q1.AutoSize = true;
            this.lbl1Q1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1Q1.ForeColor = System.Drawing.Color.White;
            this.lbl1Q1.Location = new System.Drawing.Point(66, 67);
            this.lbl1Q1.Name = "lbl1Q1";
            this.lbl1Q1.Size = new System.Drawing.Size(179, 21);
            this.lbl1Q1.TabIndex = 38;
            this.lbl1Q1.Text = "Nunca o casi nunca";
            // 
            // Rbtn1Q4
            // 
            this.Rbtn1Q4.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn1Q4.CheckedState.BorderThickness = 0;
            this.Rbtn1Q4.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn1Q4.CheckedState.InnerColor = System.Drawing.Color.White;
            this.Rbtn1Q4.Location = new System.Drawing.Point(749, 66);
            this.Rbtn1Q4.Name = "Rbtn1Q4";
            this.Rbtn1Q4.Size = new System.Drawing.Size(20, 20);
            this.Rbtn1Q4.TabIndex = 37;
            this.Rbtn1Q4.Text = "guna2CustomRadioButton4";
            this.Rbtn1Q4.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Rbtn1Q4.UncheckedState.BorderThickness = 2;
            this.Rbtn1Q4.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.Rbtn1Q4.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // Rbtn1Q3
            // 
            this.Rbtn1Q3.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn1Q3.CheckedState.BorderThickness = 0;
            this.Rbtn1Q3.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn1Q3.CheckedState.InnerColor = System.Drawing.Color.White;
            this.Rbtn1Q3.Location = new System.Drawing.Point(511, 70);
            this.Rbtn1Q3.Name = "Rbtn1Q3";
            this.Rbtn1Q3.Size = new System.Drawing.Size(20, 20);
            this.Rbtn1Q3.TabIndex = 36;
            this.Rbtn1Q3.Text = "guna2CustomRadioButton3";
            this.Rbtn1Q3.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Rbtn1Q3.UncheckedState.BorderThickness = 2;
            this.Rbtn1Q3.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.Rbtn1Q3.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            this.Rbtn1Q3.CheckedChanged += new System.EventHandler(this.guna2CustomRadioButton3_CheckedChanged);
            // 
            // Rbtn1Q2
            // 
            this.Rbtn1Q2.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn1Q2.CheckedState.BorderThickness = 0;
            this.Rbtn1Q2.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn1Q2.CheckedState.InnerColor = System.Drawing.Color.White;
            this.Rbtn1Q2.Location = new System.Drawing.Point(271, 69);
            this.Rbtn1Q2.Name = "Rbtn1Q2";
            this.Rbtn1Q2.Size = new System.Drawing.Size(20, 20);
            this.Rbtn1Q2.TabIndex = 35;
            this.Rbtn1Q2.Text = "guna2CustomRadioButton2";
            this.Rbtn1Q2.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Rbtn1Q2.UncheckedState.BorderThickness = 2;
            this.Rbtn1Q2.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.Rbtn1Q2.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // Rbtn1Q1
            // 
            this.Rbtn1Q1.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn1Q1.CheckedState.BorderThickness = 0;
            this.Rbtn1Q1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn1Q1.CheckedState.InnerColor = System.Drawing.Color.White;
            this.Rbtn1Q1.Location = new System.Drawing.Point(40, 67);
            this.Rbtn1Q1.Name = "Rbtn1Q1";
            this.Rbtn1Q1.Size = new System.Drawing.Size(20, 20);
            this.Rbtn1Q1.TabIndex = 34;
            this.Rbtn1Q1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Rbtn1Q1.UncheckedState.BorderThickness = 2;
            this.Rbtn1Q1.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.Rbtn1Q1.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(149)))), ((int)(((byte)(127)))));
            this.label5.Location = new System.Drawing.Point(101, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 19);
            this.label5.TabIndex = 33;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(164)))), ((int)(((byte)(148)))));
            this.label3.Location = new System.Drawing.Point(21, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 28);
            this.label3.TabIndex = 6;
            this.label3.Text = "VitApp";
            // 
            // GbxQ2
            // 
            this.GbxQ2.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(41)))), ((int)(((byte)(42)))));
            this.GbxQ2.Controls.Add(this.lbl2Q3);
            this.GbxQ2.Controls.Add(this.lbl2Q2);
            this.GbxQ2.Controls.Add(this.Rbtn2Q3);
            this.GbxQ2.Controls.Add(this.lbl2Q1);
            this.GbxQ2.Controls.Add(this.label4);
            this.GbxQ2.Controls.Add(this.Rbtn2Q2);
            this.GbxQ2.Controls.Add(this.Rbtn2Q1);
            this.GbxQ2.Controls.Add(this.label6);
            this.GbxQ2.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(41)))), ((int)(((byte)(42)))));
            this.GbxQ2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(41)))), ((int)(((byte)(42)))));
            this.GbxQ2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GbxQ2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.GbxQ2.Location = new System.Drawing.Point(36, 199);
            this.GbxQ2.Name = "GbxQ2";
            this.GbxQ2.Size = new System.Drawing.Size(1008, 125);
            this.GbxQ2.TabIndex = 38;
            this.GbxQ2.Text = "2.";
            // 
            // lbl2Q3
            // 
            this.lbl2Q3.AutoSize = true;
            this.lbl2Q3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2Q3.ForeColor = System.Drawing.Color.White;
            this.lbl2Q3.Location = new System.Drawing.Point(742, 74);
            this.lbl2Q3.Name = "lbl2Q3";
            this.lbl2Q3.Size = new System.Drawing.Size(204, 21);
            this.lbl2Q3.TabIndex = 44;
            this.lbl2Q3.Text = "Actividades vigorosas";
            // 
            // lbl2Q2
            // 
            this.lbl2Q2.AutoSize = true;
            this.lbl2Q2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2Q2.ForeColor = System.Drawing.Color.White;
            this.lbl2Q2.Location = new System.Drawing.Point(429, 74);
            this.lbl2Q2.Name = "lbl2Q2";
            this.lbl2Q2.Size = new System.Drawing.Size(216, 21);
            this.lbl2Q2.TabIndex = 45;
            this.lbl2Q2.Text = "Actividades moderadas";
            // 
            // Rbtn2Q3
            // 
            this.Rbtn2Q3.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn2Q3.CheckedState.BorderThickness = 0;
            this.Rbtn2Q3.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn2Q3.CheckedState.InnerColor = System.Drawing.Color.White;
            this.Rbtn2Q3.Location = new System.Drawing.Point(716, 77);
            this.Rbtn2Q3.Name = "Rbtn2Q3";
            this.Rbtn2Q3.Size = new System.Drawing.Size(20, 20);
            this.Rbtn2Q3.TabIndex = 36;
            this.Rbtn2Q3.Text = "guna2CustomRadioButton6";
            this.Rbtn2Q3.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Rbtn2Q3.UncheckedState.BorderThickness = 2;
            this.Rbtn2Q3.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.Rbtn2Q3.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // lbl2Q1
            // 
            this.lbl2Q1.AutoSize = true;
            this.lbl2Q1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2Q1.ForeColor = System.Drawing.Color.White;
            this.lbl2Q1.Location = new System.Drawing.Point(126, 70);
            this.lbl2Q1.Name = "lbl2Q1";
            this.lbl2Q1.Size = new System.Drawing.Size(249, 21);
            this.lbl2Q1.TabIndex = 52;
            this.lbl2Q1.Text = "Principalmente sedentarias";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(149)))), ((int)(((byte)(127)))));
            this.label4.Location = new System.Drawing.Point(267, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(467, 21);
            this.label4.TabIndex = 33;
            this.label4.Text = "¿Qué tipo de actividades realiza en su tiempo libre? ";
            // 
            // Rbtn2Q2
            // 
            this.Rbtn2Q2.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn2Q2.CheckedState.BorderThickness = 0;
            this.Rbtn2Q2.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn2Q2.CheckedState.InnerColor = System.Drawing.Color.White;
            this.Rbtn2Q2.Location = new System.Drawing.Point(403, 72);
            this.Rbtn2Q2.Name = "Rbtn2Q2";
            this.Rbtn2Q2.Size = new System.Drawing.Size(20, 20);
            this.Rbtn2Q2.TabIndex = 35;
            this.Rbtn2Q2.Text = "guna2CustomRadioButton7";
            this.Rbtn2Q2.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Rbtn2Q2.UncheckedState.BorderThickness = 2;
            this.Rbtn2Q2.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.Rbtn2Q2.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // Rbtn2Q1
            // 
            this.Rbtn2Q1.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn2Q1.CheckedState.BorderThickness = 0;
            this.Rbtn2Q1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn2Q1.CheckedState.InnerColor = System.Drawing.Color.White;
            this.Rbtn2Q1.Location = new System.Drawing.Point(100, 71);
            this.Rbtn2Q1.Name = "Rbtn2Q1";
            this.Rbtn2Q1.Size = new System.Drawing.Size(20, 20);
            this.Rbtn2Q1.TabIndex = 34;
            this.Rbtn2Q1.Text = "guna2CustomRadioButton8";
            this.Rbtn2Q1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Rbtn2Q1.UncheckedState.BorderThickness = 2;
            this.Rbtn2Q1.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.Rbtn2Q1.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(149)))), ((int)(((byte)(127)))));
            this.label6.Location = new System.Drawing.Point(101, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 19);
            this.label6.TabIndex = 33;
            // 
            // GbxQ3
            // 
            this.GbxQ3.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(41)))), ((int)(((byte)(42)))));
            this.GbxQ3.Controls.Add(this.lbl3Q3);
            this.GbxQ3.Controls.Add(this.lbl3Q2);
            this.GbxQ3.Controls.Add(this.lbl3Q1);
            this.GbxQ3.Controls.Add(this.Rbtn3Q3);
            this.GbxQ3.Controls.Add(this.Rbtn3Q2);
            this.GbxQ3.Controls.Add(this.Rbtn3Q1);
            this.GbxQ3.Controls.Add(this.label7);
            this.GbxQ3.Controls.Add(this.label8);
            this.GbxQ3.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(41)))), ((int)(((byte)(42)))));
            this.GbxQ3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(41)))), ((int)(((byte)(42)))));
            this.GbxQ3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GbxQ3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.GbxQ3.Location = new System.Drawing.Point(36, 330);
            this.GbxQ3.Name = "GbxQ3";
            this.GbxQ3.Size = new System.Drawing.Size(1121, 125);
            this.GbxQ3.TabIndex = 38;
            this.GbxQ3.Text = "3.";
            // 
            // lbl3Q3
            // 
            this.lbl3Q3.AutoSize = true;
            this.lbl3Q3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3Q3.ForeColor = System.Drawing.Color.White;
            this.lbl3Q3.Location = new System.Drawing.Point(742, 71);
            this.lbl3Q3.Name = "lbl3Q3";
            this.lbl3Q3.Size = new System.Drawing.Size(204, 21);
            this.lbl3Q3.TabIndex = 50;
            this.lbl3Q3.Text = "Actividades vigorosas";
            // 
            // lbl3Q2
            // 
            this.lbl3Q2.AutoSize = true;
            this.lbl3Q2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3Q2.ForeColor = System.Drawing.Color.White;
            this.lbl3Q2.Location = new System.Drawing.Point(429, 71);
            this.lbl3Q2.Name = "lbl3Q2";
            this.lbl3Q2.Size = new System.Drawing.Size(216, 21);
            this.lbl3Q2.TabIndex = 51;
            this.lbl3Q2.Text = "Actividades moderadas";
            // 
            // lbl3Q1
            // 
            this.lbl3Q1.AutoSize = true;
            this.lbl3Q1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3Q1.ForeColor = System.Drawing.Color.White;
            this.lbl3Q1.Location = new System.Drawing.Point(126, 67);
            this.lbl3Q1.Name = "lbl3Q1";
            this.lbl3Q1.Size = new System.Drawing.Size(221, 21);
            this.lbl3Q1.TabIndex = 46;
            this.lbl3Q1.Text = "Actividades muy ligeras";
            // 
            // Rbtn3Q3
            // 
            this.Rbtn3Q3.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn3Q3.CheckedState.BorderThickness = 0;
            this.Rbtn3Q3.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn3Q3.CheckedState.InnerColor = System.Drawing.Color.White;
            this.Rbtn3Q3.Location = new System.Drawing.Point(716, 74);
            this.Rbtn3Q3.Name = "Rbtn3Q3";
            this.Rbtn3Q3.Size = new System.Drawing.Size(20, 20);
            this.Rbtn3Q3.TabIndex = 49;
            this.Rbtn3Q3.Text = "guna2CustomRadioButton5";
            this.Rbtn3Q3.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Rbtn3Q3.UncheckedState.BorderThickness = 2;
            this.Rbtn3Q3.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.Rbtn3Q3.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // Rbtn3Q2
            // 
            this.Rbtn3Q2.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn3Q2.CheckedState.BorderThickness = 0;
            this.Rbtn3Q2.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn3Q2.CheckedState.InnerColor = System.Drawing.Color.White;
            this.Rbtn3Q2.Location = new System.Drawing.Point(403, 69);
            this.Rbtn3Q2.Name = "Rbtn3Q2";
            this.Rbtn3Q2.Size = new System.Drawing.Size(20, 20);
            this.Rbtn3Q2.TabIndex = 48;
            this.Rbtn3Q2.Text = "guna2CustomRadioButton9";
            this.Rbtn3Q2.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Rbtn3Q2.UncheckedState.BorderThickness = 2;
            this.Rbtn3Q2.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.Rbtn3Q2.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // Rbtn3Q1
            // 
            this.Rbtn3Q1.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn3Q1.CheckedState.BorderThickness = 0;
            this.Rbtn3Q1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn3Q1.CheckedState.InnerColor = System.Drawing.Color.White;
            this.Rbtn3Q1.Location = new System.Drawing.Point(100, 68);
            this.Rbtn3Q1.Name = "Rbtn3Q1";
            this.Rbtn3Q1.Size = new System.Drawing.Size(20, 20);
            this.Rbtn3Q1.TabIndex = 47;
            this.Rbtn3Q1.Text = "guna2CustomRadioButton10";
            this.Rbtn3Q1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Rbtn3Q1.UncheckedState.BorderThickness = 2;
            this.Rbtn3Q1.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.Rbtn3Q1.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(149)))), ((int)(((byte)(127)))));
            this.label7.Location = new System.Drawing.Point(217, 30);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(597, 21);
            this.label7.TabIndex = 33;
            this.label7.Text = "¿Cómo es la intensidad de las actividades que realiza diariamente?";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(149)))), ((int)(((byte)(127)))));
            this.label8.Location = new System.Drawing.Point(101, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 19);
            this.label8.TabIndex = 33;
            // 
            // GbxQ4
            // 
            this.GbxQ4.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(41)))), ((int)(((byte)(42)))));
            this.GbxQ4.Controls.Add(this.lbl4Q3);
            this.GbxQ4.Controls.Add(this.lbl4Q2);
            this.GbxQ4.Controls.Add(this.lbl4Q1);
            this.GbxQ4.Controls.Add(this.Rbtn4Q3);
            this.GbxQ4.Controls.Add(this.label9);
            this.GbxQ4.Controls.Add(this.Rbtn4Q2);
            this.GbxQ4.Controls.Add(this.Rbtn4Q1);
            this.GbxQ4.Controls.Add(this.label10);
            this.GbxQ4.CustomBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(41)))), ((int)(((byte)(42)))));
            this.GbxQ4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(41)))), ((int)(((byte)(42)))));
            this.GbxQ4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.GbxQ4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.GbxQ4.Location = new System.Drawing.Point(25, 461);
            this.GbxQ4.Name = "GbxQ4";
            this.GbxQ4.Size = new System.Drawing.Size(1095, 125);
            this.GbxQ4.TabIndex = 39;
            this.GbxQ4.Text = "4.";
            // 
            // lbl4Q3
            // 
            this.lbl4Q3.AutoSize = true;
            this.lbl4Q3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl4Q3.ForeColor = System.Drawing.Color.White;
            this.lbl4Q3.Location = new System.Drawing.Point(756, 60);
            this.lbl4Q3.Name = "lbl4Q3";
            this.lbl4Q3.Size = new System.Drawing.Size(222, 21);
            this.lbl4Q3.TabIndex = 42;
            this.lbl4Q3.Text = "Pocas o ninguna barrera";
            // 
            // lbl4Q2
            // 
            this.lbl4Q2.AutoSize = true;
            this.lbl4Q2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl4Q2.ForeColor = System.Drawing.Color.White;
            this.lbl4Q2.Location = new System.Drawing.Point(440, 60);
            this.lbl4Q2.Name = "lbl4Q2";
            this.lbl4Q2.Size = new System.Drawing.Size(159, 21);
            this.lbl4Q2.TabIndex = 43;
            this.lbl4Q2.Text = "Algunas barreras";
            // 
            // lbl4Q1
            // 
            this.lbl4Q1.AutoSize = true;
            this.lbl4Q1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl4Q1.ForeColor = System.Drawing.Color.White;
            this.lbl4Q1.Location = new System.Drawing.Point(137, 59);
            this.lbl4Q1.Name = "lbl4Q1";
            this.lbl4Q1.Size = new System.Drawing.Size(160, 21);
            this.lbl4Q1.TabIndex = 44;
            this.lbl4Q1.Text = "Muchas barreras ";
            // 
            // Rbtn4Q3
            // 
            this.Rbtn4Q3.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn4Q3.CheckedState.BorderThickness = 0;
            this.Rbtn4Q3.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn4Q3.CheckedState.InnerColor = System.Drawing.Color.White;
            this.Rbtn4Q3.Location = new System.Drawing.Point(725, 61);
            this.Rbtn4Q3.Name = "Rbtn4Q3";
            this.Rbtn4Q3.Size = new System.Drawing.Size(20, 20);
            this.Rbtn4Q3.TabIndex = 36;
            this.Rbtn4Q3.Text = "guna2CustomRadioButton14";
            this.Rbtn4Q3.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Rbtn4Q3.UncheckedState.BorderThickness = 2;
            this.Rbtn4Q3.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.Rbtn4Q3.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(149)))), ((int)(((byte)(127)))));
            this.label9.Location = new System.Drawing.Point(262, 28);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(531, 21);
            this.label9.TabIndex = 33;
            this.label9.Text = "¿Tiene muchas barreras que le impidan realizar ejercicios? ";
            // 
            // Rbtn4Q2
            // 
            this.Rbtn4Q2.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn4Q2.CheckedState.BorderThickness = 0;
            this.Rbtn4Q2.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn4Q2.CheckedState.InnerColor = System.Drawing.Color.White;
            this.Rbtn4Q2.Location = new System.Drawing.Point(414, 60);
            this.Rbtn4Q2.Name = "Rbtn4Q2";
            this.Rbtn4Q2.Size = new System.Drawing.Size(20, 20);
            this.Rbtn4Q2.TabIndex = 35;
            this.Rbtn4Q2.Text = "guna2CustomRadioButton15";
            this.Rbtn4Q2.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Rbtn4Q2.UncheckedState.BorderThickness = 2;
            this.Rbtn4Q2.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.Rbtn4Q2.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // Rbtn4Q1
            // 
            this.Rbtn4Q1.CheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn4Q1.CheckedState.BorderThickness = 0;
            this.Rbtn4Q1.CheckedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.Rbtn4Q1.CheckedState.InnerColor = System.Drawing.Color.White;
            this.Rbtn4Q1.Location = new System.Drawing.Point(111, 59);
            this.Rbtn4Q1.Name = "Rbtn4Q1";
            this.Rbtn4Q1.Size = new System.Drawing.Size(20, 20);
            this.Rbtn4Q1.TabIndex = 34;
            this.Rbtn4Q1.Text = "guna2CustomRadioButton16";
            this.Rbtn4Q1.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(137)))), ((int)(((byte)(149)))));
            this.Rbtn4Q1.UncheckedState.BorderThickness = 2;
            this.Rbtn4Q1.UncheckedState.FillColor = System.Drawing.Color.Transparent;
            this.Rbtn4Q1.UncheckedState.InnerColor = System.Drawing.Color.Transparent;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(149)))), ((int)(((byte)(127)))));
            this.label10.Location = new System.Drawing.Point(101, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(0, 19);
            this.label10.TabIndex = 33;
            // 
            // guna2TileButton2
            // 
            this.guna2TileButton2.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton2.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(84)))), ((int)(((byte)(123)))), ((int)(((byte)(114)))));
            this.guna2TileButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2TileButton2.ForeColor = System.Drawing.Color.White;
            this.guna2TileButton2.Location = new System.Drawing.Point(1028, 592);
            this.guna2TileButton2.Name = "guna2TileButton2";
            this.guna2TileButton2.Size = new System.Drawing.Size(112, 36);
            this.guna2TileButton2.TabIndex = 40;
            this.guna2TileButton2.Text = "Siguiente";
            this.guna2TileButton2.Click += new System.EventHandler(this.guna2TileButton2_Click);
            // 
            // BtnAtrás
            // 
            this.BtnAtrás.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.BtnAtrás.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.BtnAtrás.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.BtnAtrás.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.BtnAtrás.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(84)))), ((int)(((byte)(123)))), ((int)(((byte)(114)))));
            this.BtnAtrás.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.BtnAtrás.ForeColor = System.Drawing.Color.White;
            this.BtnAtrás.Location = new System.Drawing.Point(26, 592);
            this.BtnAtrás.Name = "BtnAtrás";
            this.BtnAtrás.Size = new System.Drawing.Size(112, 36);
            this.BtnAtrás.TabIndex = 41;
            this.BtnAtrás.Text = "Atrás";
            this.BtnAtrás.Click += new System.EventHandler(this.BtnAtrás_Click);
            // 
            // FormEstadoFisico
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(41)))), ((int)(((byte)(42)))));
            this.ClientSize = new System.Drawing.Size(1152, 645);
            this.Controls.Add(this.BtnAtrás);
            this.Controls.Add(this.guna2TileButton2);
            this.Controls.Add(this.GbxQ4);
            this.Controls.Add(this.GbxQ3);
            this.Controls.Add(this.GbxQ2);
            this.Controls.Add(this.GbxQ1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.guna2ControlBox3);
            this.Controls.Add(this.guna2ControlBox2);
            this.Controls.Add(this.guna2ControlBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormEstadoFisico";
            this.Text = "FormEstadoFisico";
            this.GbxQ1.ResumeLayout(false);
            this.GbxQ1.PerformLayout();
            this.GbxQ2.ResumeLayout(false);
            this.GbxQ2.PerformLayout();
            this.GbxQ3.ResumeLayout(false);
            this.GbxQ3.PerformLayout();
            this.GbxQ4.ResumeLayout(false);
            this.GbxQ4.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox3;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox2;
        private Guna.UI2.WinForms.Guna2ControlBox guna2ControlBox1;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2GroupBox GbxQ1;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2CustomRadioButton Rbtn1Q4;
        private Guna.UI2.WinForms.Guna2CustomRadioButton Rbtn1Q3;
        private Guna.UI2.WinForms.Guna2CustomRadioButton Rbtn1Q2;
        private Guna.UI2.WinForms.Guna2CustomRadioButton Rbtn1Q1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2GroupBox GbxQ4;
        private Guna.UI2.WinForms.Guna2CustomRadioButton Rbtn4Q3;
        private System.Windows.Forms.Label label9;
        private Guna.UI2.WinForms.Guna2CustomRadioButton Rbtn4Q2;
        private Guna.UI2.WinForms.Guna2CustomRadioButton Rbtn4Q1;
        private System.Windows.Forms.Label label10;
        private Guna.UI2.WinForms.Guna2GroupBox GbxQ3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private Guna.UI2.WinForms.Guna2GroupBox GbxQ2;
        private Guna.UI2.WinForms.Guna2CustomRadioButton Rbtn2Q3;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2CustomRadioButton Rbtn2Q2;
        private Guna.UI2.WinForms.Guna2CustomRadioButton Rbtn2Q1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lbl2Q3;
        private System.Windows.Forms.Label lbl2Q2;
        private System.Windows.Forms.Label lbl3Q1;
        private System.Windows.Forms.Label lbl1Q3;
        private System.Windows.Forms.Label lbl1Q2;
        private System.Windows.Forms.Label lbl1Q4;
        private System.Windows.Forms.Label lbl1Q1;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton2;
        private Guna.UI2.WinForms.Guna2TileButton BtnAtrás;
        private System.Windows.Forms.Label lbl4Q3;
        private System.Windows.Forms.Label lbl4Q2;
        private System.Windows.Forms.Label lbl4Q1;
        private System.Windows.Forms.Label lbl3Q3;
        private System.Windows.Forms.Label lbl3Q2;
        private Guna.UI2.WinForms.Guna2CustomRadioButton Rbtn3Q3;
        private Guna.UI2.WinForms.Guna2CustomRadioButton Rbtn3Q2;
        private Guna.UI2.WinForms.Guna2CustomRadioButton Rbtn3Q1;
        private System.Windows.Forms.Label lbl2Q1;
    }
}